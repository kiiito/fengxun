package com.hucong.qqClient.service;

import com.hucong.qqCommon.Message;
import com.hucong.qqCommon.MessageType;

import java.io.*;

public class FileClientServer {
    public void sendFileToOne(String src, String dst, String senderId, String getterId) throws IOException {
        Message message = new Message();
        message.setSender(senderId);
        message.setMesType(MessageType.MESSAGE_FILE_MES);
        message.setSendTime(new java.util.Date().toString());
        message.setSrc(src);
        message.setDest(dst);
        message.setGetter(getterId);
        FileInputStream fileInputStream = null;
        byte[] bytes = new byte[(int) new File(src).length()];
        fileInputStream = new FileInputStream(src);
        fileInputStream.read(bytes);//��src�ļ����뵽������ֽ�����
        //���ļ���Ӧ���ֽ��������õ�message
        message.setFileBytes(bytes);
        if (fileInputStream != null){
            fileInputStream.close();
        }
        System.out.println(getterId + " ���û� " + getterId + " �����ļ� " + src);

        ObjectOutputStream oos = new ObjectOutputStream
                (ManageClientConnectServerThread.getClientConnectServerThread(senderId).getSocket().getOutputStream());
        oos.writeObject(message);
    }
}
