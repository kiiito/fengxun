package com.hucong.qqClient.service;
import com.hucong.qqClient.utils.Utility;
import com.hucong.qqCommon.Message;
import com.hucong.qqCommon.MessageType;
import com.hucong.qqCommon.User;
import com.sun.org.apache.xml.internal.serializer.utils.Utils;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

public class UserClientService {
    private User u = new User();
    private Socket socket;
    public boolean checkUser(String userId, String pwd) throws IOException, ClassNotFoundException {
        boolean b = false;
        u.setUserId(userId);
        u.setPassword(pwd);
        //���ӷ����� ����u����
        socket = new Socket(InetAddress.getByName("127.0.0.1"), 9999);
        ObjectOutputStream obs = new ObjectOutputStream(socket.getOutputStream());
        obs.writeObject(u);
        //obs.close();

        //��ȡ�ӷ������ظ���Message����
        ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
        Message ms = (Message) ois.readObject();
        if (ms.getMesType().equals(MessageType.MESSAGE_LOGIN_SUCCESS)){
            ClientConnectServerThread cst = new ClientConnectServerThread(socket);
            //�����ͻ����߳�
            cst.start();
            //�ͻ�����չ ���̷߳��뼯�Ϲ���
            ManageClientConnectServerThread.addClientConnectServerThread(userId,cst);
            b = true;
        }else {
            //�����½ʧ�� �Ͳ��������߳�
           socket.close();
        }
        return b;
    }
    public void onlineFriendList(){
        //����һ��message����
        Message message = new Message();
        message.setMesType(MessageType.MESSAGE_GET_ONLINE_FRIEND);
        message.setSender(u.getUserId());
        try {
            //�õ���ǰ�̵߳�socket��Ӧ��ObjectOutputStream����
            ObjectOutputStream oos = new ObjectOutputStream
                    (ManageClientConnectServerThread.getClientConnectServerThread(u.getUserId()).getSocket().getOutputStream());
            oos.writeObject(message);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public void logout(){
        Message message = new Message();
        message.setMesType(MessageType.MESSAGE_CLIENT_EXIT);
        message.setSender(u.getUserId());
        try {
            ObjectOutputStream oos = new ObjectOutputStream
                    (ManageClientConnectServerThread.getClientConnectServerThread(u.getUserId()).getSocket().getOutputStream());
            oos.writeObject(message);
            System.out.println(u.getUserId() + " �˳�ϵͳ");
            System.exit(0);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public void sendMessageToAll(String content, String senderId){
        Message message = new Message();
        message.setContent(content);
        message.setSender(senderId);
        message.setSendTime(new java.util.Date().toString());
        System.out.println(senderId + " ���ҷ��� " + content);
        message.setMesType(MessageType.MESSAGE_TO_ALL_MES);
        try {
            ObjectOutputStream oos = new ObjectOutputStream
                    (ManageClientConnectServerThread.getClientConnectServerThread(senderId).getSocket().getOutputStream());
            oos.writeObject(message);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
