package com.hucong.qqClient.service;

import java.util.HashMap;

public class ManageClientConnectServerThread {
     private static HashMap<String,ClientConnectServerThread> hm = new HashMap<>();
     //��ĳ���̼߳��뵽���ϵ���
     public static void addClientConnectServerThread(String userId,ClientConnectServerThread clientConnectServerThread) {
         hm.put(userId,clientConnectServerThread);
     }
     //ͨ��userId �õ���Ӧ���߳�
    public static ClientConnectServerThread getClientConnectServerThread(String userId) {
         return hm.get(userId);
    }
}
